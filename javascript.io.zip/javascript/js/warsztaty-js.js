'use strict';


function multiply (i1, i2, i3) {
    var result = i1 * i2 * i3;
    
    return result;
}


var wynikIloczynu = multiply (5,7,2);

console.log(wynikIloczynu);



function silnia(10) {
   if ((n == 0) )
      return 1
   else {
      
   }
}
