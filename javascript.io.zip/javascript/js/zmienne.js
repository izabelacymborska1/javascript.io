'use strict';

var imie;
var imieDamskie = "Kaja";
var wiek = 37;

var kolor = "czerwony";

imie = "Sergio";


imie = imieDamskie;


console.log(imie);
console.log(imieDamskie);
console.log(wiek);


