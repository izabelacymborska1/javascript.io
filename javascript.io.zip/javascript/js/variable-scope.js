'use strict';




function multiply (l1, l2, l3) {
    var result = l1 * l2 * l3
    
    return result;
}


var wynikMnozenia = multiply (3,4,5);

console.log(wynikMnozenia);