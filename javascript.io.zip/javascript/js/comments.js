'use strict';

console.log("Akademia 108")