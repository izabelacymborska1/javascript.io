'use strict';
var wzrostMateusz = 190;
var wzrostOlgi = 150;


//warunek if
//if (wzrostOlgi <wzrostMateusz) {
//    console.log("Olga jest niższa;)");
//}

//if (wzrostOlgi > wzrostMateusz) {
//    console.log("Olga jest wyższa;)");
//} else {
//   console.log("Olga jest niższa;)");     
//
//}


//warunek if else if


//if (wzrostOlgi > wzrostMateusz) {
//    console.log("Olga jest wyższa;)");
//} else if (wzrostOlgi == wzrostMateusz)
//    console.log("Olga jest tak wysoka jak Mateusz");
//else {
//   console.log("Olga jest niższa;)");  
//}


//switch

var kolor = 'zielony';
switch (kolor) {
        
    case 'czerwony':
        console.log('Kolor czerwony')
        break;
        case 'zielony':
        console.log('Kolor zielony')
        break;
        case 'niebieski':
        console.log('Kolor niebieski')
        break;
    default:
        console.log('Inny kolor')
        
        
}