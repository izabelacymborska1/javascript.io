'use strict';

//obiekt math

console.log( Math.PI);

console.log(Math.cos(0));
console.log(Math.random);


