'use strict'

var liczba1 = 13, liczba2 = 5;
var wynik;
wynik =  liczba1 % liczba2;


wynik +=3;

wynik +=3;
console.log(wynik);

if (wynik = 7) {
    console.log("prawda")
    
    } else {
        console.log("fałsz")
    }


(3>2) ? console.log("prawda") : console.log("fałsz");
