'use strict';

//typ liczbowy

var wyplata = 5000;
var premia = 2500;
var calkowitaWyplata = wyplata + premia;

calkowitaWyplata = wyplata + premia;
console.log(calkowitaWyplata);


//typ-łancuch znakow- string 

var wyplataStr = "5000";
var premiaStr = "2500";
var calkowtaWyplataStr;

calkowitaWyplataStr = WyplataStr + premiaStr;

console.log(calkowitaWyplataStr);


//typ logiczny

var czyJestSmog;
czyJestSmog = true;
if (czyJestSmog) {
    console.log("jest Smog");
    }
else {
    console.log("Nie ma SMOGA");
}

//typ specjalny nul

var niezdefiniowanaZmienna;
var nullowZmienna = null;
console.log(niezdefiniowanaZmienna);
console.log(nullowZmienna);

