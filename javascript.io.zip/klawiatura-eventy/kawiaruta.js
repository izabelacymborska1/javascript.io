'use strict';

//keyprees



document.getElementsByTagName('body')[0].addEventListener('keypress', function(e){
    
    console.log(e);  
})



keydown

document.getElementsByTagName('body')[0].addEventListener('keydown', function(e){
    
    console.log(e);
})


keyup

document.getElementsByTagName('body')[0].addEventListener('keyup', function(e){
    
    console.log(e);  
})
